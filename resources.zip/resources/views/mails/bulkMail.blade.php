@component("mail::message")


Hi {{ $username }}

{{ $details['title'] }}

{{""}}

{{ $details['message'] }}


@component('mail::subcopy')
Davetrack Technologies is a leading enterprise at securing our clients/customers by providing them with substantial products that meet their needs. for more enquiries reach at to us at support@davetracktechnologies.com
@endcomponent

@endcomponent

